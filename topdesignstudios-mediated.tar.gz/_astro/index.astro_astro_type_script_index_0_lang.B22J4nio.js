import{C as m,t}from"./home.BzqB6MmZ.js";import{m as e}from"./renderer.D7cte6Tr.js";import"./formtomail.BPBYoDgG.js";e(document.getElementById("page"),t,new m);
