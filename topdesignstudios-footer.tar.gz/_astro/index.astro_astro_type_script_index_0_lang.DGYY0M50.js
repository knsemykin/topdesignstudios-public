import{C as m,t}from"./home.BNBil_Lp.js";import{m as e}from"./renderer.Dxl9t6XX.js";import"./formtomail.DxT41TKp.js";e(document.getElementById("page"),t,new m);
