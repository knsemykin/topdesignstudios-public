import{C as e,t as m}from"./home.B2bfR15M.js";import{m as t}from"./renderer.DyEYf2yQ.js";t(document.getElementById("page"),m,new e);
