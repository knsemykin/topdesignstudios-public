import{C as m,t}from"./home.OaCSoOO1.js";import{m as e}from"./renderer.xUqRR7xB.js";import"./formtomail.ChAXQvoP.js";e(document.getElementById("page"),t,new m);
